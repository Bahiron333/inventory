export const enviroment = {
    production: false,
    //url: 'http://localhost:4200',
    app: 'Inventory'
}