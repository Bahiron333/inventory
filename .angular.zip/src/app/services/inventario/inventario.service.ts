import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InventarioService {

  constructor(private http:HttpClient) {
      this.headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`
    })
   }

  getNewActivo(idCliente:string, activo:any):Observable<any>{
    return this.http.post(`http://localhost:3000/cliente/${idCliente}/inventario/crearInventario`,{activo},{headers: this.headers});
  }
  
  NewActivo(idCliente:string, idInventario:string,newActivo:any):Observable<any>{
    console.log(newActivo)
    return this.http.post(`http://localhost:3000/${idCliente}/inventario/${idInventario}/crearActivo`,{newActivo},{headers: this.headers});
  }

  //esta sesion es para los activos 
  getActivos(idCliente:string, categoria:string, tipo:string):Observable<any>{
    return this.http.get(`http://localhost:3000/cliente/${idCliente}/inventario/${categoria}/${tipo}`,{headers: this.headers});
  }

    //esta sesion es para los activos 
  getCamposAdicionales(idCliente:string, categoria:string):Observable<any>{
    return this.http.get(`http://localhost:3000/inventario/${categoria}/camposAdicionales`,{headers: this.headers});
  }

  private headers:any = null;
  private token = localStorage.getItem('token');
}
